/*
 * fsm_automatic.h
 *
 *  Created on: Oct 25, 2022
 *      Author: PC
 */

#ifndef INC_FSM_AUTOMATIC_H_
#define INC_FSM_AUTOMATIC_H_


#include "TrafficLight.h"
#include "global.h"

void fsm1_automatic_run();
void fsm2_automatic_run();

#endif /* INC_FSM_AUTOMATIC_H_ */
