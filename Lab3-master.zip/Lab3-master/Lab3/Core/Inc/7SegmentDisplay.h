/*
 * 7SegmentDisplay.h
 *
 *  Created on: Oct 25, 2022
 *      Author: PC
 */

#ifndef INC_7SEGMENTDISPLAY_H_
#define INC_7SEGMENTDISPLAY_H_

#include "main.h"

#define LED7PORT GPIOB

void update7Segment();

#endif /* INC_7SEGMENTDISPLAY_H_ */
